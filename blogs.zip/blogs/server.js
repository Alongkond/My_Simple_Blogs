const express = require('express')
const path = require('path')
const createError = require('http-errors')
const expressLayouts = require('express-ejs-layouts')
const app = express()
require('dotenv').config()
const morgan = require('morgan')
const router = require('./routes/auth_routers.js')

app.use(morgan('dev'))
app.use(express.json())
app.use(expressLayouts)
app.set('view engine','ejs')
app.use(express.static('public'))
app.use(express.urlencoded({extended:true}))

app.get('/',async(req,res,next)=>{
    res.render('index')
})

app.use('/article',router)

app.use(async(req,res,next)=>{
    next(createError.NotFound())
})

app.use((err,req,res,next)=>{
    res.status(err.status || 500)
    res.send({
        status:err.status,
        message:err.message
    })
})

const PORT = process.env.PORT || 3000

app.listen(PORT,()=>{
    console.log(`server's running on port ${PORT}`)
})