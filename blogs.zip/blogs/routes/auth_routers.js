const router = require('express').Router()

router.get('/login',(req,res)=>{
    res.send('this is login page.')
})

router.get('/new',(req,res,next)=>{
    res.render('article/new')
})

module.exports = router